    #     ___  ____     _    ____ _     _____
    #    / _ \|  _ \   / \  / ___| |   | ____|
    #   | | | | |_) | / _ \| |   | |   |  _|
    #   | |_| |  _ < / ___ | |___| |___| |___
    #    \___/|_| \_/_/   \_\____|_____|_____|
***

## Object Storage Resource and Datasource Examples

This example demonstrates the following Object Storage concepts:
* Creating Objects and buckets 
* Defining Preauthenticated Requests for objects and buckets 
* Accessing and modifying object store namespace metatdata
