    #     ___  ____     _    ____ _     _____
    #    / _ \|  _ \   / \  / ___| |   | ____|
    #   | | | | |_) | / _ \| |   | |   |  _|
    #   | |_| |  _ < / ___ | |___| |___| |___
    #    \___/|_| \_/_/   \_\____|_____|_____|
***

## Multi-Region Provider Configuration

This example demonstrates how to:
* Define multiple OCI providers targeting different regions
* List and filter Availability Domains across regions
